This font is for PERSONAL USE ONLY!.

If you want to use this font for commercial purposes, you will need to purchase a commercial license. You can purchase a commercial license at 

https://allsuperfont.com/product/super-sunday/

Introducing “Super Sunday,” a font that captures the essence of laid-back Sundays with a touch of retro flair. It’s the perfect fit for injecting a dose of personality into your designs, whether it’s for branding, invitations, posters, or just adding a unique touch to your social media posts.